make html
LC_ALL=C make man
