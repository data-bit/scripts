This directory contains support files for appveyor, a continuous integration
service which runs tests on Windows on every push.
